const express = require("express");
const app = express();
const path = require("path");

const static_path = path.join(__dirname, "../public");
const templatePath = path.join(__dirname, "../templates");

app.set("view engine", "hbs");
app.set("views", templatePath);

app.use(express.static(static_path));

app.get("/", (req, res) => {
  res.send("Hello, world!");
});

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
